# 诊断报告

诊断 ID：quick-diag-08183121b46840b683ee7d9fb308f507-20260625-095558

时间范围：2026-06-16T07:06:42.260+00:00 ~ 2026-06-16T07:16:42.400+00:00

## 一、总览

| # | traceId | 日志条数 | SQL 条数 |
|---|---------|----------|----------|
| 1 | `08183121b46840b683ee7d9fb308f507` | 9 | 2 |

---

## 二、排查详情

### 1. traceId：`08183121b46840b683ee7d9fb308f507`

#### 关键日志

```text
[2026-06-16T07:11:42.260Z] [INFO] [08183121b46840b683ee7d9fb308f507] [unknown] [-] RequestUrl:[/v1/pt/speech-module/list]
[2026-06-16T07:11:42.358Z] [DEBUG] [08183121b46840b683ee7d9fb308f507] [unknown] [-] ==>  Preparing: SELECT count(0) FROM (SELECT DISTINCT t.ID AS id, t.SPEECH_NAME AS name, t.SYSTEM_SPEECH_NAME systemSpeechName, t.SPEECH_INTRO AS speechIntro, t.SPEECH_STATUS AS speechStatus, t.SPEECH_CRAFT_ID AS speechCraftId, t.dept_id AS deptId, t.disease_id AS diseaseId, t.disease_name AS diseaseName, t.CREATE_TIME FROM tb_speech_craft t WHERE t.deleted = 0) table_count
[2026-06-16T07:11:42.358Z] [DEBUG] [08183121b46840b683ee7d9fb308f507] [unknown] [-] ==> Parameters: 
[2026-06-16T07:11:42.385Z] [DEBUG] [08183121b46840b683ee7d9fb308f507] [unknown] [-] <==      Total: 1
[2026-06-16T07:11:42.391Z] [DEBUG] [08183121b46840b683ee7d9fb308f507] [unknown] [-] ==>  Preparing: select distinct t.ID as id, t.SPEECH_NAME as name, t.SYSTEM_SPEECH_NAME systemSpeechName, t.SPEECH_INTRO as speechIntro, t.SPEECH_STATUS as speechStatus, t.SPEECH_CRAFT_ID as speechCraftId, t.dept_id as deptId, t.disease_id as diseaseId, t.disease_name as diseaseName, t.CREATE_TIME FROM tb_speech_craft t WHERE t.deleted = 0 ORDER BY t.CREATE_TIME desc LIMIT ?
[2026-06-16T07:11:42.394Z] [DEBUG] [08183121b46840b683ee7d9fb308f507] [unknown] [-] ==> Parameters: 10(Integer)
[2026-06-16T07:11:42.400Z] [DEBUG] [08183121b46840b683ee7d9fb308f507] [unknown] [-] <==      Total: 10
```

#### 相关 SQL 与执行计划

## 1. tb_speech_craft

| 项目 | 值 |
|------|-----|
| traceId | `08183121b46840b683ee7d9fb308f507` |
| 服务 | unknown |
| 时间 | 2026-06-16T07:11:42.358Z |
| 参数 | `","namespace":"jfyf-hzfw-test-pg","traceId":"5313d1e0f8b941a1a605e4d63e9e7ff7.276.17815939022590087","type":"1","userId":"pcm","x0":"08183121b46840b683ee7d9fb308f507","x1":"全病程","x2":"/v1/pt/speech-module/list","x3":"http-nio-18080-exec-8"}` |
| 涉及表 | tb_speech_craft |

**SQL 语句（已拼装参数）：**

```sql
SELECT count(0) FROM (SELECT DISTINCT t.ID AS id, t.SPEECH_NAME AS name, t.SYSTEM_SPEECH_NAME systemSpeechName, t.SPEECH_INTRO AS speechIntro, t.SPEECH_STATUS AS speechStatus, t.SPEECH_CRAFT_ID AS speechCraftId, t.dept_id AS deptId, t.disease_id AS diseaseId, t.disease_name AS diseaseName, t.CREATE_TIME FROM tb_speech_craft t WHERE t.deleted = 0) table_count
```

**表数据量与索引：**

| 表名 | 行数 | 数据大小 | 索引数 | 索引列表 |
|------|------|----------|--------|----------|
| outbound_platform_2912.tb_speech_craft | 276 | 368,640 bytes | 1 | `idx_31029_primary(id) UNIQUE` |

**执行计划（log_sql_explain - 来自 schema: pcm_2912）：**

```json
[
  {
    "Plan": {
      "Async Capable": false,
      "Node Type": "Aggregate",
      "Parallel Aware": false,
      "Partial Mode": "Simple",
      "Plan Rows": 1,
      "Plan Width": 8,
      "Plans": [
        {
          "Async Capable": false,
          "Node Type": "Unique",
          "Parallel Aware": false,
          "Parent Relationship": "Outer",
          "Plan Rows": 2,
          "Plan Width": 410,
          "Plans": [
            {
              "Async Capable": false,
              "Node Type": "Sort",
              "Parallel Aware": false,
              "Parent Relationship": "Outer",
              "Plan Rows": 2,
              "Plan Width": 410,
              "Plans": [
                {
                  "Async Capable": false,
                  "Inner Unique": true,
                  "Join Type": "Left",
                  "Node Type": "Nested Loop",
                  "Parallel Aware": false,
                  "Parent Relationship": "Outer",
                  "Plan Rows": 2,
                  "Plan Width": 410,
                  "Plans": [
                    {
                      "Async Capable": false,
                      "Inner Unique": true,
                      "Join Type": "Left",
                      "Node Type": "Nested Loop",
                      "Parallel Aware": false,
                      "Parent Relationship": "Outer",
                      "Plan Rows": 2,
                      "Plan Width": 288,
                      "Plans": [
                        {
                          "Async Capable": false,
                          "Inner Unique": true,
                          "Join Type": "Left",
                          "Node Type": "Nested Loop",
                          "Parallel Aware": false,
                          "Parent Relationship": "Outer",
                          "Plan Rows": 2,
                          "Plan Width": 288,
                          "Plans": [
                            {
                              "Async Capable": false,
                              "Inner Unique": false,
                              "Join Type": "Left",
                              "Node Type": "Nested Loop",
                              "Parallel Aware": false,
                              "Parent Relationship": "Outer",
                              "Plan Rows": 2,
                              "Plan Width": 268,
                              "Plans": [
                                {
                                  "Async Capable": false,
                                  "Filter": "(COALESCE((tmm.del_flag)::integer, 0) = 0)",
                                  "Hash Cond": "(((sc.id)::character varying)::text = (tmm.module_id)::text)",
                                  "Inner Unique": false,
                                  "Join Type": "Left",
                                  "Node Type": "Hash Join",
                                  "Parallel Aware": false,
                                  "Parent Relationship": "Outer",
                                  "Plan Rows": 2,
                                  "Plan Width": 268,
                                  "Plans": [
                                    {
                                      "Alias": "sc",
                                      "Async Capable": false,
                                      "Filter": "(deleted = 0)",
                                      "Node Type": "Seq Scan",
                                      "Parallel Aware": false,
                                      "Parent Relationship": "Outer",
                                      "Plan Rows": 276,
                                      "Plan Width": 260,
                                      "Relation Name": "tb_speech_craft",
                                      "Startup Cost": 0.0,
                                      "Total Cost": 40.45
                                    },
                                    {
                                      "Async Capable": false,
                                      "Node Type": "Hash",
                                      "Parallel Aware": false,
                                      "Parent Relationship": "Inner",
                                      "Plan Rows": 140,
                                      "Plan Width": 92,
                                      "Plans": [
                                        {
                                          "Alias": "tmm",
                                          "Async Capable": false,
                                          "Node Type": "Seq Scan",
                                          "Parallel Aware": false,
                                          "Parent Relationship": "Outer",
                                          "Plan Rows": 140,
                                          "Plan Width": 92,
                                          "Relation Name": "tb_manage_module",
                                          "Startup Cost": 0.0,
                                          "Total Cost": 11.4
                                        }
                                      ],
                                      "Startup Cost": 11.4,
                                      "Total Cost": 11.4
                                    }
                                  ],
                                  "Startup Cost": 13.15,
                                  "Total Cost": 58.22
                                },
                                {
                                  "Alias": "sbr",
                                  "Async Capable": false,
                                  "Filter": "((type = 1) AND (speech_plat = 1))",
                                  "Index Cond": "(speechid = sc.id)",
                                  "Index Name": "idx_30989_idx_speech_id",
                                  "Node Type": "Index Scan",
                                  "Parallel Aware": false,
                                  "Parent Relationship": "Inner",
                                  "Plan Rows": 1,
                                  "Plan Width": 8,
                                  "Relation Name": "tb_speech_business_rel",
                                  "Scan Direction": "Forward",
                                  "Startup Cost": 0.28,
                                  "Total Cost": 1.09
                                }
                              ],
                              "Startup Cost": 13.43,
                              "Total Cost": 60.41
                            },
                            {
                              "Alias": "tdd",
                              "Async Capable": false,
                              "Index Cond": "(id = tmm.manager_id)",
                              "Index Name": "tb_dept_disease_pkey",
                              "Node Type": "Index Scan",
                              "Parallel Aware": false,
                              "Parent Relationship": "Inner",
                              "Plan Rows": 1,
                              "Plan Width": 36,
                              "Relation Name": "tb_dept_disease",
                              "Scan Direction": "Forward",
                              "Startup Cost": 0.28,
                              "Total Cost": 0.39
                            }
                          ],
                          "Startup Cost": 13.71,
                          "Total Cost": 61.18
                        },
                        {
                          "Alias": "td",
                          "Async Capable": false,
                          "Index Cond": "(id = tdd.dept_id)",
                          "Index Name": "tb_dept_pkey",
                          "Node Type": "Index Only Scan",
                          "Parallel Aware": false,
                          "Parent Relationship": "Inner",
                          "Plan Rows": 1,
                          "Plan Width": 8,
                          "Relation Name": "tb_dept",
                          "Scan Direction": "Forward",
                          "Startup Cost": 0.14,
                          "Total Cost": 0.18
                        }
                      ],
                      "Startup Cost": 13.85,
                      "Total Cost": 61.55
                    },
                    {
                      "Alias": "dis",
                      "Async Capable": false,
                      "Index Cond": "((id)::text = (tdd.disease_id)::text)",
                      "Index Name": "tb_disease_pkey",
                      "Node Type": "Index Scan",
                      "Parallel Aware": false,
                      "Parent Relationship": "Inner",
                      "Plan Rows": 1,
                      "Plan Width": 36,
                      "Relation Name": "tb_disease",
                      "Scan Direction": "Forward",
                      "Startup Cost": 0.27,
                      "Total Cost": 0.36
                    },
                    {
                      "Async Capable": false,
                      "Node Type": "Aggregate",
                      "Parallel Aware": false,
                      "Parent Relationship": "SubPlan",
                      "Partial Mode": "Simple",
                      "Plan Rows": 1,
                      "Plan Width": 32,
                      "Plans": [
                        {
                          "Alias": "sbr_1",
                          "Async Capable": false,
                          "Filter": "(type = 1)",
                          "Index Cond": "(speechid = sc.id)",
                          "Index Name": "idx_30989_idx_speech_id",
                          "Node Type": "Index Scan",
                          "Parallel Aware": false,
                          "Parent Relationship": "Outer",
                          "Plan Rows": 3,
                          "Plan Width": 19,
                          "Relation Name": "tb_speech_business_rel",
                          "Scan Direction": "Forward",
                          "Startup Cost": 0.28,
                          "Total Cost": 10.27
                        }
                      ],
                      "Startup Cost": 10.28,
                      "Strategy": "Plain",
                      "Subplan Name": "SubPlan 1",
                      "Total Cost": 10.29
                    }
                  ],
                  "Startup Cost": 14.12,
                  "Total Cost": 82.86
                }
              ],
              "Sort Key": [
                "((sc.id)::character varying(32))",
                "sc.speech_name",
                "sc.system_speech_name",
                "sc.speech_intro",
                "sc.speech_status",
                "((SubPlan 1))",
                "(COALESCE(td.id, '1668912686216376322'::bigint))",
                "tdd.disease_id",
                "dis.disease_name",
                "sc.create_time"
              ],
              "Startup Cost": 82.87,
              "Total Cost": 82.88
            }
          ],
          "Startup Cost": 82.87,
          "Total Cost": 82.93
        }
      ],
      "Startup Cost": 82.95,
      "Strategy": "Plain",
      "Total Cost": 82.96
    }
  }
]
```

---

## 2. tb_speech_craft

| 项目 | 值 |
|------|-----|
| traceId | `08183121b46840b683ee7d9fb308f507` |
| 服务 | unknown |
| 时间 | 2026-06-16T07:11:42.391Z |
| 参数 | `10(Integer)` |
| 涉及表 | tb_speech_craft |

**SQL 语句（已拼装参数）：**

```sql
select distinct t.ID as id, t.SPEECH_NAME as name, t.SYSTEM_SPEECH_NAME systemSpeechName, t.SPEECH_INTRO as speechIntro, t.SPEECH_STATUS as speechStatus, t.SPEECH_CRAFT_ID as speechCraftId, t.dept_id as deptId, t.disease_id as diseaseId, t.disease_name as diseaseName, t.CREATE_TIME FROM tb_speech_craft t WHERE t.deleted = 0 ORDER BY t.CREATE_TIME desc LIMIT 10
```

**表数据量与索引：**

| 表名 | 行数 | 数据大小 | 索引数 | 索引列表 |
|------|------|----------|--------|----------|
| outbound_platform_2912.tb_speech_craft | 276 | 368,640 bytes | 1 | `idx_31029_primary(id) UNIQUE` |

**执行计划（log_sql_explain - 来自 schema: pcm_2912）：**

```json
[
  {
    "Plan": {
      "Async Capable": false,
      "Node Type": "Limit",
      "Parallel Aware": false,
      "Plan Rows": 2,
      "Plan Width": 410,
      "Plans": [
        {
          "Async Capable": false,
          "Node Type": "Unique",
          "Parallel Aware": false,
          "Parent Relationship": "Outer",
          "Plan Rows": 2,
          "Plan Width": 410,
          "Plans": [
            {
              "Async Capable": false,
              "Node Type": "Sort",
              "Parallel Aware": false,
              "Parent Relationship": "Outer",
              "Plan Rows": 2,
              "Plan Width": 410,
              "Plans": [
                {
                  "Async Capable": false,
                  "Inner Unique": true,
                  "Join Type": "Left",
                  "Node Type": "Nested Loop",
                  "Parallel Aware": false,
                  "Parent Relationship": "Outer",
                  "Plan Rows": 2,
                  "Plan Width": 410,
                  "Plans": [
                    {
                      "Async Capable": false,
                      "Inner Unique": true,
                      "Join Type": "Left",
                      "Node Type": "Nested Loop",
                      "Parallel Aware": false,
                      "Parent Relationship": "Outer",
                      "Plan Rows": 2,
                      "Plan Width": 288,
                      "Plans": [
                        {
                          "Async Capable": false,
                          "Inner Unique": true,
                          "Join Type": "Left",
                          "Node Type": "Nested Loop",
                          "Parallel Aware": false,
                          "Parent Relationship": "Outer",
                          "Plan Rows": 2,
                          "Plan Width": 288,
                          "Plans": [
                            {
                              "Async Capable": false,
                              "Inner Unique": false,
                              "Join Type": "Left",
                              "Node Type": "Nested Loop",
                              "Parallel Aware": false,
                              "Parent Relationship": "Outer",
                              "Plan Rows": 2,
                              "Plan Width": 268,
                              "Plans": [
                                {
                                  "Async Capable": false,
                                  "Filter": "(COALESCE((tmm.del_flag)::integer, 0) = 0)",
                                  "Hash Cond": "(((sc.id)::character varying)::text = (tmm.module_id)::text)",
                                  "Inner Unique": false,
                                  "Join Type": "Left",
                                  "Node Type": "Hash Join",
                                  "Parallel Aware": false,
                                  "Parent Relationship": "Outer",
                                  "Plan Rows": 2,
                                  "Plan Width": 268,
                                  "Plans": [
                                    {
                                      "Alias": "sc",
                                      "Async Capable": false,
                                      "Filter": "(deleted = 0)",
                                      "Node Type": "Seq Scan",
                                      "Parallel Aware": false,
                                      "Parent Relationship": "Outer",
                                      "Plan Rows": 276,
                                      "Plan Width": 260,
                                      "Relation Name": "tb_speech_craft",
                                      "Startup Cost": 0.0,
                                      "Total Cost": 40.45
                                    },
                                    {
                                      "Async Capable": false,
                                      "Node Type": "Hash",
                                      "Parallel Aware": false,
                                      "Parent Relationship": "Inner",
                                      "Plan Rows": 140,
                                      "Plan Width": 92,
                                      "Plans": [
                                        {
                                          "Alias": "tmm",
                                          "Async Capable": false,
                                          "Node Type": "Seq Scan",
                                          "Parallel Aware": false,
                                          "Parent Relationship": "Outer",
                                          "Plan Rows": 140,
                                          "Plan Width": 92,
                                          "Relation Name": "tb_manage_module",
                                          "Startup Cost": 0.0,
                                          "Total Cost": 11.4
                                        }
                                      ],
                                      "Startup Cost": 11.4,
                                      "Total Cost": 11.4
                                    }
                                  ],
                                  "Startup Cost": 13.15,
                                  "Total Cost": 58.22
                                },
                                {
                                  "Alias": "sbr",
                                  "Async Capable": false,
                                  "Filter": "((type = 1) AND (speech_plat = 1))",
                                  "Index Cond": "(speechid = sc.id)",
                                  "Index Name": "idx_30989_idx_speech_id",
                                  "Node Type": "Index Scan",
                                  "Parallel Aware": false,
                                  "Parent Relationship": "Inner",
                                  "Plan Rows": 1,
                                  "Plan Width": 8,
                                  "Relation Name": "tb_speech_business_rel",
                                  "Scan Direction": "Forward",
                                  "Startup Cost": 0.28,
                                  "Total Cost": 1.09
                                }
                              ],
                              "Startup Cost": 13.43,
                              "Total Cost": 60.41
                            },
                            {
                              "Alias": "tdd",
                              "Async Capable": false,
                              "Index Cond": "(id = tmm.manager_id)",
                              "Index Name": "tb_dept_disease_pkey",
                              "Node Type": "Index Scan",
                              "Parallel Aware": false,
                              "Parent Relationship": "Inner",
                              "Plan Rows": 1,
                              "Plan Width": 36,
                              "Relation Name": "tb_dept_disease",
                              "Scan Direction": "Forward",
                              "Startup Cost": 0.28,
                              "Total Cost": 0.39
                            }
                          ],
                          "Startup Cost": 13.71,
                          "Total Cost": 61.18
                        },
                        {
                          "Alias": "td",
                          "Async Capable": false,
                          "Index Cond": "(id = tdd.dept_id)",
                          "Index Name": "tb_dept_pkey",
                          "Node Type": "Index Only Scan",
                          "Parallel Aware": false,
                          "Parent Relationship": "Inner",
                          "Plan Rows": 1,
                          "Plan Width": 8,
                          "Relation Name": "tb_dept",
                          "Scan Direction": "Forward",
                          "Startup Cost": 0.14,
                          "Total Cost": 0.18
                        }
                      ],
                      "Startup Cost": 13.85,
                      "Total Cost": 61.55
                    },
                    {
                      "Alias": "dis",
                      "Async Capable": false,
                      "Index Cond": "((id)::text = (tdd.disease_id)::text)",
                      "Index Name": "tb_disease_pkey",
                      "Node Type": "Index Scan",
                      "Parallel Aware": false,
                      "Parent Relationship": "Inner",
                      "Plan Rows": 1,
                      "Plan Width": 36,
                      "Relation Name": "tb_disease",
                      "Scan Direction": "Forward",
                      "Startup Cost": 0.27,
                      "Total Cost": 0.36
                    },
                    {
                      "Async Capable": false,
                      "Node Type": "Aggregate",
                      "Parallel Aware": false,
                      "Parent Relationship": "SubPlan",
                      "Partial Mode": "Simple",
                      "Plan Rows": 1,
                      "Plan Width": 32,
                      "Plans": [
                        {
                          "Alias": "sbr_1",
                          "Async Capable": false,
                          "Filter": "(type = 1)",
                          "Index Cond": "(speechid = sc.id)",
                          "Index Name": "idx_30989_idx_speech_id",
                          "Node Type": "Index Scan",
                          "Parallel Aware": false,
                          "Parent Relationship": "Outer",
                          "Plan Rows": 3,
                          "Plan Width": 19,
                          "Relation Name": "tb_speech_business_rel",
                          "Scan Direction": "Forward",
                          "Startup Cost": 0.28,
                          "Total Cost": 10.27
                        }
                      ],
                      "Startup Cost": 10.28,
                      "Strategy": "Plain",
                      "Subplan Name": "SubPlan 1",
                      "Total Cost": 10.29
                    }
                  ],
                  "Startup Cost": 14.12,
                  "Total Cost": 82.86
                }
              ],
              "Sort Key": [
                "sc.create_time DESC",
                "((sc.id)::character varying(32))",
                "sc.speech_name",
                "sc.system_speech_name",
                "sc.speech_intro",
                "sc.speech_status",
                "((SubPlan 1))",
                "(COALESCE(td.id, '1668912686216376322'::bigint))",
                "tdd.disease_id",
                "dis.disease_name"
              ],
              "Startup Cost": 82.87,
              "Total Cost": 82.88
            }
          ],
          "Startup Cost": 82.87,
          "Total Cost": 82.93
        }
      ],
      "Startup Cost": 82.87,
      "Total Cost": 82.93
    }
  }
]
```

---

---

